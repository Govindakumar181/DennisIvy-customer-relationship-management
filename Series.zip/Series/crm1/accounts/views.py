from django.shortcuts import render, redirect 
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group

# Create your views here.
from .models import *
from .forms import OrderForm, CreateUserForm
from .filters import OrderFilter
from .decorators import unauthenticated_user,allowed_users,admin_only

@unauthenticated_user
def registerPage(request):

    form = CreateUserForm()
    if request.method=="POST":
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='customer')
            user.groups.add(group)
            Customer.objects.create(
                user=user,
            )

            messages.success(request, 'Account was created for ' + username)

            return redirect('Login')

        
    contex = {'form':form}
    return render(request,"accounts/register.html",contex)

@unauthenticated_user
def loginPage(request):
    if request.method=="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request,username=username,password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
            
        else:
            messages.info(request, 'Username OR password is incorrect')

    contex={}
    return render(request,"accounts/login.html",contex)

def logoutUser(request):

    logout(request)
    return redirect('Login')


@login_required(login_url='Login')
@allowed_users(allowed_roles=['customer'])
def userPage(request):
    orders = request.user.customer.order_set.all()

    total_orders = orders.count()
    order_delivered = orders.filter(status = "Delivered").count()
    order_pending = orders.filter(status = "Pending").count()

    contex = {"orders":orders,
    "total_orders":total_orders,
    "order_delivered":order_delivered,
    "order_pending":order_pending
    }
    return render(request,"accounts/user.html",contex)



@login_required(login_url='Login')
@admin_only
def home(request):
    order = Order.objects.all()
    customer = Customer.objects.all()

    total_customers = customer.count()

    total_orders = order.count()
    order_delivered = order.filter(status = "Delivered").count()
    order_pending = order.filter(status = "Pending").count()

    contex = {"orders":order,"customers":customer,
    "total_orders":total_orders,
    "order_delivered":order_delivered,
    "order_pending":order_pending
    }
    return render(request,"accounts/dashboard.html",contex)


@login_required(login_url='Login')
@allowed_users(allowed_roles=['admin'])
def products(request):
    p = Product.objects.all()
    #p2 = Product.objects.filter(category="Outdoor")
    return render(request,"accounts/products.html",{"products":p})



@login_required(login_url='Login')
@allowed_users(allowed_roles=['admin'])
def customers(request,pk_test):
    customer = Customer.objects.get(id=pk_test)
    order = customer.order_set.all()
    total_order = order.count()
    myFilter = OrderFilter(request.GET, queryset=order)
    order = myFilter.qs

    contex = {"customers":customer,"orders":order,"total_order":total_order,"myFilter":myFilter}

    return render(request,"accounts/customers.html",contex)

@login_required(login_url='Login')
@allowed_users(allowed_roles=['admin'])
def createOrder(request, pk):
    OrderFormSet = inlineformset_factory(Customer,Order,fields=('product','status'),extra=9)
    customer = Customer.objects.get(id=pk)
    formset = OrderFormSet(queryset=Order.objects.none(),instance=customer)
    #order = OrderForm(initial={"customer":customer})

    if request.method=="POST":
        #print("Printing Order submitting Data",request.POST)
        form = OrderForm(request.POST)
        formset = OrderFormSet(request.POST,instance=customer)
        if formset.is_valid():
            formset.save()
            return redirect("/")


    contex = {"form":formset}

    return render(request,"accounts/create_order.html",contex)

@login_required(login_url='Login')
@allowed_users(allowed_roles=['admin'])
def updateOrder(request, pk):
    order = Order.objects.get(id=pk)
    form = OrderForm(instance=order)
    
    if request.method=="POST":
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect("/")

    
    contex = {"form":form}
    return render(request,"accounts/create_order.html",contex)

@login_required(login_url='Login')
@allowed_users(allowed_roles=['admin'])
def deleteOrder(request, pk):

    delete_order=Order.objects.get(id=pk)

    if request.method=="POST":
        delete_order.delete()
        return redirect("/")

    contex = {"item":delete_order}
    return render(request,"accounts/delete_order.html",contex)
