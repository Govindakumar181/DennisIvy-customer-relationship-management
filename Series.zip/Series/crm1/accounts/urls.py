from django.urls import path
from . import views as v

urlpatterns = [
    path('',v.home,name="home"),
    path('products/',v.products,name="products"),
    path('customers/<str:pk_test>/',v.customers,name="customers"),
    path('user/',v.userPage,name="User"),


    path('CreateOrder/<str:pk>/',v.createOrder,name="CreateOrder"),
    path('UpdateOrder/<str:pk>/',v.updateOrder,name="UpdateOrder"),
    path('DeleteOrder/<str:pk>/',v.deleteOrder,name="DeleteOrder"),

    path('register/',v.registerPage,name="Register"),
    path('login/',v.loginPage,name="Login"),
    path('logout/',v.logoutUser,name="Logout"),
    
    
    


]
